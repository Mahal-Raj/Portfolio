// Keep the recovered Next.js interface intact while making route changes use
// full document navigations on static hosting. All page interactions remain
// owned by the original August 24 application bundles.
document.addEventListener("click", (event) => {
  const anchor = event.target.closest("a[href]");
  if (!anchor || event.defaultPrevented || event.button !== 0) return;
  if (anchor.target === "_blank" || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;

  const url = new URL(anchor.href, window.location.href);
  if (url.origin !== window.location.origin || url.pathname === window.location.pathname) return;

  event.preventDefault();
  event.stopImmediatePropagation();
  window.location.assign(url.href);
}, true);
